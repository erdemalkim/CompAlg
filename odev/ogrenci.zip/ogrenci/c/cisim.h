#ifndef CISIM_H
#define CISIM_H

#include <stdint.h>

/*
 * F_p sonlu cismi; p < 2^32 bir asal.
 * Elemanlar 0 <= a < p aralığında uint32_t olarak tutulur.
 * Testler p'yi cisim_sec ile ayarlar; kodunuzda P'yi okuyabilirsiniz.
 * Bu dosyadaki fonksiyonlar hazırdır; değiştirmeyin.
 */
typedef uint32_t el;

extern el P;                      /* geçerli asal p */

void cisim_sec(el p);             /* P = p            */

el el_topla(el a, el b);          /* a + b            */
el el_cikar(el a, el b);          /* a - b            */
el el_carp(el a, el b);           /* a * b            */
el el_us(el a, uint64_t e);       /* a^e              */

/*
 * Genişletilmiş Öklid algoritması (tamsayılarda).
 * g = gcd(a, b) döndürür ve s*a + t*b = g olacak şekilde *s, *t yazar.
 */
int64_t gen_oklid(int64_t a, int64_t b, int64_t *s, int64_t *t);

#endif /* CISIM_H */
