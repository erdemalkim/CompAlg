/*
 * Test programı. Değiştirmeyin.
 * Girdi: tek bir tamsayı K. K >= 10 ise n = 2^10, 2^12, ..., 2^K
 * boyutlarında hız testleri de çalışır (K <= 20).
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "cisim.h"
#include "poly.h"
#include "odev.h"

static uint64_t durum;
static el rastgele(void) {                 /* xorshift64 */
    durum ^= durum << 13;
    durum ^= durum >> 7;
    durum ^= durum << 17;
    return (el)(durum % P);
}

#define P_BUYUK 998244353u

struct test { el p; size_t n; el w; };

static const struct test testler[] = {
    {      97,  1,          5 },
    {      97,  8,         64 },
    {      97,  6,          6 },
    {      97, 12,          6 },
    {      97, 10,         64 },
    {      97, 16,          8 },
    {      97,  7,         35 },
    {      97, 24,          4 },
    {      97, 20,          2 },
    { P_BUYUK,  8, 372528824 },
    { P_BUYUK, 10, 929031873 },
    { P_BUYUK, 14, 467509451 },
    { P_BUYUK,  6, 779057549 },
    { P_BUYUK, 32, 922799308 },
    { P_BUYUK, 16,         3 },
    { P_BUYUK,  6, 911660635 },
};

static const el hiz_w[] = {               /* p = P_BUYUK; n = 2^10, ..., 2^20 */
    258648936, 63912897, 666702199, 629671588, 996173970, 565042129
};

static int ayni(const el *a, const el *b, size_t n) {
    for (size_t i = 0; i < n; i++)
        if (a[i] != b[i]) return 0;
    return 1;
}

/*
 * c = a*b rem m, bileşenlerde: değerlendir, bileşen bileşen çarp,
 * interpole et (sizin iki fonksiyonunuzu kullanır). a, b, c: n uzunluklu.
 */
static void carp_mod(const el *a, const el *b, size_t n, el w, el *c) {
    el *va = poly_yeni(n), *vb = poly_yeni(n);
    degerlendir(a, n, w, va);
    degerlendir(b, n, w, vb);
    for (size_t i = 0; i < n; i++) va[i] = el_carp(va[i], vb[i]);
    interpole(va, n, w, c);
    free(va); free(vb);
}

static const char *sonuc(int d) { return d ? "TAMAM" : "HATALI"; }

static int dogruluk_testleri(void) {
    size_t say = sizeof testler / sizeof testler[0];
    int gecen = 0;
    printf("Test          p   n          w  değerlendirme  interpolasyon  çarpım mod m\n");
    for (size_t t = 0; t < say; t++) {
        size_t n = testler[t].n;
        el w = testler[t].w;
        cisim_sec(testler[t].p);
        el *f = poly_yeni(n), *g = poly_yeni(n), *v = poly_yeni(n);
        el *beklenen = poly_yeni(n), *h = poly_yeni(n), *c = poly_yeni(n);
        el *fg = poly_yeni(2 * n - 1), *m = poly_yeni(n + 1);
        el *fg_mod_m = poly_yeni(n);

        durum = 0x9E3779B97F4A7C15ull * (t + 1);
        for (size_t i = 0; i < n; i++) f[i] = rastgele();
        for (size_t i = 0; i < n; i++) g[i] = rastgele();
        el u = 1;
        for (size_t i = 0; i < n; i++) {
            beklenen[i] = poly_horner(f, n, u);
            u = el_carp(u, w);
        }

        degerlendir(f, n, w, v);
        int d1 = ayni(v, beklenen, n);
        interpole(beklenen, n, w, h);
        int d2 = ayni(h, f, n);
        poly_carp(f, n, g, n, fg);                  /* doğrudan a*b rem m */
        poly_m(w, n, m);
        poly_bol(fg, 2 * n - 1, m, n + 1, NULL, fg_mod_m);
        carp_mod(f, g, n, w, c);
        int d3 = ayni(c, fg_mod_m, n);

        printf("%4zu  %9u  %2zu  %9u  %-14s %-14s %s\n", t + 1,
               (unsigned)testler[t].p, n, (unsigned)w,
               sonuc(d1), sonuc(d2), sonuc(d3));
        gecen += d1 + d2 + d3;
        free(f); free(g); free(v); free(beklenen); free(h); free(c);
        free(fg); free(m); free(fg_mod_m);
    }
    printf("Toplam: %d / %zu\n", gecen, 3 * say);
    return gecen;
}

static void hiz_testi(int k, el w) {
    size_t n = (size_t)1 << k;
    el *f = poly_yeni(n), *v = poly_yeni(n), *g = poly_yeni(n);
    durum = 12345 + (uint64_t)k;
    for (size_t i = 0; i < n; i++) f[i] = rastgele();

    clock_t t0 = clock();
    degerlendir(f, n, w, v);
    clock_t t1 = clock();
    interpole(v, n, w, g);
    clock_t t2 = clock();

    /* Birkaç noktayı Horner ile denetle */
    int d1 = 1;
    for (int j = 0; j < 5; j++) {
        size_t i = rastgele() % n;
        if (v[i] != poly_horner(f, n, el_us(w, i))) d1 = 0;
    }
    int d2 = ayni(f, g, n);
    printf("n = 2^%-2d  değerlendirme %8.3f s %-7s interpolasyon"
           " %8.3f s %s\n", k,
           (double)(t1 - t0) / CLOCKS_PER_SEC, sonuc(d1),
           (double)(t2 - t1) / CLOCKS_PER_SEC, sonuc(d2));
    free(f); free(v); free(g);
}

int main(void) {
    int K = 0;
    if (scanf("%d", &K) != 1) K = 0;

    dogruluk_testleri();
    if (K >= 10) {
        printf("\nHız testleri (p = %u)\n", P_BUYUK);
        cisim_sec(P_BUYUK);
        for (int k = 10; k <= K && k <= 20; k += 2)
            hiz_testi(k, hiz_w[(k - 10) / 2]);
    }
    return 0;
}
