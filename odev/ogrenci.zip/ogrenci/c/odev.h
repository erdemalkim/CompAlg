#ifndef ODEV_H
#define ODEV_H

#include <stddef.h>
#include "cisim.h"

/*
 * Değerlendirme: f, n katsayılı bir polinom (f[i] = x^i'nin katsayısı).
 * out[i] = f(w^i),  i = 0, 1, ..., n-1.
 */
void degerlendir(const el *f, size_t n, el w, el *out);

/*
 * İnterpolasyon: v, n değer.
 * Derecesi n'den küçük ve her i = 0, ..., n-1 için f(w^i) = v[i]
 * sağlayan f'nin katsayılarını out'a yazar (out[i] = x^i'nin katsayısı).
 */
void interpole(const el *v, size_t n, el w, el *out);

#endif /* ODEV_H */
