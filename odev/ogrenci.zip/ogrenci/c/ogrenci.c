/*
 * Ad Soyad  :
 * Numara    :
 *
 * Yalnızca bu dosyayı düzenleyin. Teslim, ödev sayfasındaki PDF ile yapılır.
 * cisim.h ve poly.h içindeki hazır fonksiyonları kullanabilirsiniz.
 */
#include <stdlib.h>
#include <string.h>
#include "cisim.h"
#include "poly.h"
#include "odev.h"

void degerlendir(const el *f, size_t n, el w, el *out) {
    /* TODO */
    (void)f; (void)w;
    memset(out, 0, n * sizeof(el));
}

void interpole(const el *v, size_t n, el w, el *out) {
    /* TODO */
    (void)v; (void)w;
    memset(out, 0, n * sizeof(el));
}
