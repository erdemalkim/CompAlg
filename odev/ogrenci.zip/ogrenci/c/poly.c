#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "poly.h"

el *poly_yeni(size_t n) {
    el *f = calloc(n ? n : 1, sizeof(el));
    if (f == NULL) {
        fprintf(stderr, "poly_yeni: bellek yetersiz\n");
        exit(1);
    }
    return f;
}

el poly_horner(const el *f, size_t n, el a) {
    el s = 0;
    for (size_t i = n; i-- > 0; )
        s = el_topla(el_carp(s, a), f[i]);
    return s;
}

void poly_topla(const el *a, const el *b, size_t n, el *c) {
    for (size_t i = 0; i < n; i++) c[i] = el_topla(a[i], b[i]);
}

void poly_cikar(const el *a, const el *b, size_t n, el *c) {
    for (size_t i = 0; i < n; i++) c[i] = el_cikar(a[i], b[i]);
}

void poly_olcekle(const el *a, size_t n, el k, el *c) {
    for (size_t i = 0; i < n; i++) c[i] = el_carp(a[i], k);
}

size_t poly_carp(const el *a, size_t na, const el *b, size_t nb, el *c) {
    if (na == 0 || nb == 0) return 0;
    size_t nc = na + nb - 1;
    memset(c, 0, nc * sizeof(el));
    for (size_t i = 0; i < na; i++)
        for (size_t j = 0; j < nb; j++)
            c[i + j] = el_topla(c[i + j], el_carp(a[i], b[j]));
    return nc;
}

void poly_bol(const el *a, size_t na, const el *b, size_t nb,
              el *q, el *r) {
    el *k = poly_yeni(na);                /* ara kalan */
    memcpy(k, a, na * sizeof(el));
    /* u = lc(b)^(-1) mod P: gen_oklid ile s*lc + t*P = 1 => u = s mod P */
    int64_t s, t;
    gen_oklid(b[nb - 1], P, &s, &t);
    s %= (int64_t)P;
    el u = (el)(s < 0 ? s + P : s);
    if (na >= nb) {
        for (size_t i = na - nb + 1; i-- > 0; ) {
            el c = el_carp(k[i + nb - 1], u);
            if (q) q[i] = c;
            for (size_t j = 0; j < nb; j++)
                k[i + j] = el_cikar(k[i + j], el_carp(c, b[j]));
        }
    }
    if (r) {
        size_t nr = nb - 1;
        for (size_t i = 0; i < nr; i++) r[i] = i < na ? k[i] : 0;
    }
    free(k);
}

void poly_m(el w, size_t n, el *m) {
    el *tmp = poly_yeni(n + 1);
    size_t nm = 1;
    el u = 1;
    m[0] = 1;
    for (size_t i = 0; i < n; i++) {           /* m <- m * (x - w^i) */
        el carpan[2] = { el_cikar(0, u), 1 };
        nm = poly_carp(m, nm, carpan, 2, tmp);
        memcpy(m, tmp, nm * sizeof(el));
        u = el_carp(u, w);
    }
    free(tmp);
}

void poly_yazdir(const char *ad, const el *f, size_t n) {
    printf("%s = [", ad);
    for (size_t i = 0; i < n; i++)
        printf(i ? ", %u" : "%u", (unsigned)f[i]);
    printf("]\n");
}
