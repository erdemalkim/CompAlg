#include "cisim.h"

el P = 97;

void cisim_sec(el p) {
    P = p;
}

el el_topla(el a, el b) {
    uint64_t c = (uint64_t)a + b;      /* p > 2^31 olabilir: 64 bitte topla */
    return (el)(c >= P ? c - P : c);
}

el el_cikar(el a, el b) {
    return a >= b ? a - b : a + (P - b);
}

el el_carp(el a, el b) {
    return (el)((uint64_t)a * b % P);
}

/* Ardışık kare alma */
el el_us(el a, uint64_t e) {
    el s = 1 % P;
    while (e > 0) {
        if (e & 1) s = el_carp(s, a);
        a = el_carp(a, a);
        e >>= 1;
    }
    return s;
}

/* Genişletilmiş Öklid: her adımda s_i*a + t_i*b = r_i korunur */
int64_t gen_oklid(int64_t a, int64_t b, int64_t *s, int64_t *t) {
    int64_t r0 = a, r1 = b, s0 = 1, s1 = 0, t0 = 0, t1 = 1;
    while (r1 != 0) {
        int64_t q = r0 / r1, tmp;
        tmp = r0 - q * r1; r0 = r1; r1 = tmp;
        tmp = s0 - q * s1; s0 = s1; s1 = tmp;
        tmp = t0 - q * t1; t0 = t1; t1 = tmp;
    }
    *s = s0;
    *t = t0;
    return r0;
}
