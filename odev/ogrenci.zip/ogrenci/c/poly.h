#ifndef POLY_H
#define POLY_H

#include <stddef.h>
#include "cisim.h"

/*
 * F_p[x] polinomları: n uzunluklu el dizisi, f[i] = x^i'nin katsayısı.
 * Bu dosyadaki fonksiyonlar hazırdır; değiştirmeyin.
 */

/* Sıfırlarla dolu n uzunluklu dizi ayırır (free ile serbest bırakın). */
el *poly_yeni(size_t n);

/* f(a), Horner kuralı ile. */
el poly_horner(const el *f, size_t n, el a);

/* c = a + b  ve  c = a - b  (üçü de n uzunluklu; c, a ya da b olabilir) */
void poly_topla(const el *a, const el *b, size_t n, el *c);
void poly_cikar(const el *a, const el *b, size_t n, el *c);

/* c = k * a  (n uzunluklu; c, a olabilir) */
void poly_olcekle(const el *a, size_t n, el k, el *c);

/* c = a * b, klasik çarpma. c'nin uzunluğu na + nb - 1 olmalı;
 * c, a ve b'den farklı bir dizi olmalı. Uzunluğu döndürür. */
size_t poly_carp(const el *a, size_t na, const el *b, size_t nb, el *c);

/* Kalanlı bölme: a = q*b + r, deg r < deg b.
 * b[nb-1] != 0 olmalı. q'nun uzunluğu na - nb + 1 (na >= nb ise),
 * r'nin uzunluğu nb - 1. q ya da r NULL verilirse yazılmaz. */
void poly_bol(const el *a, size_t na, const el *b, size_t nb,
              el *q, el *r);

/* m = (x - w^0)(x - w^1)...(x - w^(n-1)); m'nin uzunluğu n + 1. */
void poly_m(el w, size_t n, el *m);

/* "ad = [f0, f1, ...]" biçiminde yazdırır. */
void poly_yazdir(const char *ad, const el *f, size_t n);

#endif /* POLY_H */
