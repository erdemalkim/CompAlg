# Ad Soyad :
# Numara   :
#
# Yalnızca "SİZİN KODUNUZ" bölümünü düzenleyin.
# Polinomlar F_p elemanlarından oluşan listelerdir: f[i] = x^i'nin katsayısı.

# ===================== HAZIR YARDIMCILAR (değiştirmeyin) =====================
def cisim_sec(q):
    """Kullanılan cismi seçer: F = GF(q), p = q (testler çağırır)."""
    global p, F
    p, F = q, GF(q)

cisim_sec(97)

def gen_oklid(a, b):
    """Genişletilmiş Öklid (tamsayılarda): (g, s, t), s*a + t*b = g = gcd(a, b)."""
    r0, r1, s0, s1, t0, t1 = ZZ(a), ZZ(b), 1, 0, 0, 1
    while r1 != 0:
        q = r0 // r1
        r0, r1 = r1, r0 - q*r1
        s0, s1 = s1, s0 - q*s1
        t0, t1 = t1, t0 - q*t1
    return r0, s0, t0

def us(a, e):
    """a^e, ardışık kare alma ile."""
    a, s = F(a), F(1)
    while e > 0:
        if e % 2 == 1:
            s *= a
        a *= a
        e //= 2
    return s

def horner(f, a):
    """f(a)"""
    s = F(0)
    for c in reversed(f):
        s = s*a + c
    return s

def topla(a, b):
    n = max(len(a), len(b))
    a = a + [F(0)]*(n - len(a)); b = b + [F(0)]*(n - len(b))
    return [x + y for x, y in zip(a, b)]

def cikar(a, b):
    return topla(a, [-y for y in b])

def olcekle(a, k):
    return [k*x for x in a]

def carp(a, b):
    """Klasik çarpma."""
    if not a or not b:
        return []
    c = [F(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            c[i + j] += x*y
    return c

def bol(a, b):
    """Kalanlı bölme: (q, r), a = q*b + r, len(r) = len(b) - 1. b[-1] != 0."""
    k, nb = list(a), len(b)
    g, s, t = gen_oklid(b[-1], p)              # s*lc(b) + t*p = 1
    u = F(s)                                   # u = lc(b)^(-1)
    q = [F(0)] * max(len(a) - nb + 1, 0)
    for i in reversed(range(len(q))):
        c = k[i + nb - 1] * u
        q[i] = c
        for j in range(nb):
            k[i + j] -= c * b[j]
    r = (k + [F(0)]*nb)[:nb - 1]
    return q, r

def m_polinomu(w, n):
    """m = (x - w^0)(x - w^1)...(x - w^(n-1)), n+1 katsayı."""
    m = [F(1)]
    for i in range(n):
        m = carp(m, [-us(w, i), F(1)])
    return m

def carp_mod(a, b, w):
    """a*b rem m, bileşenlerde: değerlendir, bileşen bileşen çarp,
    interpole et (sizin iki fonksiyonunuzu kullanır)."""
    va, vb = degerlendir(a, w), degerlendir(b, w)
    return interpole([x*y for x, y in zip(va, vb)], w)

# ============================ SİZİN KODUNUZ ==================================
# Sage'in hazır polinom halkalarını, interpolasyon fonksiyonlarını ve hazır ters
# işlemlerini (1/a, a^(-1), inverse_mod ...) kullanmayın; yalnızca yukarıdaki
# yardımcıları ve F'de toplama, çıkarma, çarpmayı kullanın.

def degerlendir(f, w):
    """f: n katsayı. [f(w^0), f(w^1), ..., f(w^(n-1))] döndürür."""
    n = len(f)
    # TODO
    return [F(0)] * n

def interpole(v, w):
    """v: n değer. Derecesi n'den küçük ve f(w^i) = v[i] olan f'nin
    katsayılarını [f0, f1, ..., f(n-1)] döndürür."""
    n = len(v)
    # TODO
    return [F(0)] * n

# ============================ TESTLER (değiştirmeyin) ========================
HIZ_K = 0     # 10 ya da daha büyük: n = 2^10, 2^12, ..., 2^HIZ_K hız testleri

P_BUYUK = 998244353
testler = [(97, 1, 5), (97, 8, 64), (97, 6, 6), (97, 12, 6), (97, 10, 64),
           (97, 16, 8), (97, 7, 35), (97, 24, 4), (97, 20, 2),
           (P_BUYUK, 8, 372528824), (P_BUYUK, 10, 929031873),
           (P_BUYUK, 14, 467509451), (P_BUYUK, 6, 779057549),
           (P_BUYUK, 32, 922799308), (P_BUYUK, 16, 3), (P_BUYUK, 6, 911660635)]
hiz_w = {10: 258648936, 12: 63912897, 14: 666702199}     # p = P_BUYUK

def sonuc(d):
    return "TAMAM" if d else "HATALI"

set_random_seed(2026)
gecen = 0
print("Test          p   n          w  değerlendirme  interpolasyon  çarpım mod m")
for t, (q, n, w) in enumerate(testler, 1):
    cisim_sec(q)
    w = F(w)
    f = [F.random_element() for _ in range(n)]
    g = [F.random_element() for _ in range(n)]
    beklenen = [horner(f, w^i) for i in range(n)]
    d1 = degerlendir(f, w) == beklenen
    d2 = interpole(beklenen, w) == f
    _, fg_mod_m = bol(carp(f, g), m_polinomu(w, n))     # doğrudan a*b rem m
    d3 = carp_mod(f, g, w) == fg_mod_m
    gecen += d1 + d2 + d3
    print("%4d  %9d  %2d  %9d  %-13s  %-13s  %s"
          % (t, q, n, int(w), sonuc(d1), sonuc(d2), sonuc(d3)))
print("Toplam: %d / %d" % (gecen, 3*len(testler)))

if HIZ_K >= 10:
    print("\nHız testleri (p = %d)" % P_BUYUK)
    cisim_sec(P_BUYUK)
for k in range(10, min(HIZ_K, 14) + 1, 2):
    n, w = 2^k, F(hiz_w[k])
    f = [F.random_element() for _ in range(n)]
    t0 = walltime(); v = degerlendir(f, w); t1 = walltime()
    g = interpole(v, w); t2 = walltime()
    d1 = all(v[i] == horner(f, w^i) for i in (ZZ.random_element(n) for _ in range(5)))
    print("n = 2^%-2d  değerlendirme %7.3f s %-7s interpolasyon %7.3f s %s"
          % (k, t1 - t0, sonuc(d1), t2 - t1, sonuc(g == f)))
